//package com.dao;
//
//import com.model.Product;
//
//public interface CartItemsDao 
//{
//	public Product getCartItems(Product product);
//}
