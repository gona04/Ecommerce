package com.dao;

import com.model.Users;

public interface UserDao 
{
	void addUser(Users user);
}
