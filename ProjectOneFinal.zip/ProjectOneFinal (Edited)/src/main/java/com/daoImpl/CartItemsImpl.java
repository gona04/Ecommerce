/*package com.daoImpl;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.dao.CartItemsDao;
import com.model.Product;

public class CartItemsImpl implements CartItemsDao 
{
	@Autowired
	SessionFactory sessionFactory;

	@Override
	public Product getCartItems(Product product) 
	{
		System.out.println("product Id is" + product.getProductId());
		return null;
	}
	
	

}
*/
